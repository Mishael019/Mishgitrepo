var express = require("express"),
router  = express.Router(),
Dino = require("../models/Dino");

//!+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//!                                 RESTFUL ROUTES
//!+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//* ==========> ||  HOME PAGE ||   <==========     //
router.get("/" , function(req , res){

    res.render("dinos/home");
});

//!==========================================================
//!       1-   INDEX ROUTE - LIST ALL BLOGS
//!===========================================================
router.get("/dinos" ,  function(req ,res){

//! RETRIEVING ALL DATA FROM DATABASE AND DISPLAYING IT ON THE BLOG SITE

Dino.find({} , function(err , dinos){

        if(err){console.log("SOMETHING WENT WRONG!!");
                console.log(err)
    }
       else{   res.render("dinos/index", {dinos : dinos}); }
    })
})

//!================================================================
//!         2-       NEW ROUTE - SHOW NEW BLOG FORM
//!===============================================================

router.get("/dinos/new", isLoggedIn, function(req , res){

    res.render("dinos/new");
})

//!================================================================
//!        3-       CREATE ROUTE - CREATE A NEW BLOG
//!================================================================

router.post("/dinos" , isLoggedIn, function(req , res){


    Dino.create(req.body.dinos, function(err , newDino){

        if(err){ console.log("ERROR!!");
                  res.render('dinos/new' , {dinos:newDino})}
        else{ res.redirect('/dinos');
              }

            });


});

//!=====================================================================================
//!                           4- SHOW ROUTE - SHOW INFO ABOUT ONE SPECIFIC BLOG
//!======================================================================================

router.get("/dinos/:id" ,isLoggedIn, function(req , res){

    Dino.findById(req.params.id, function(err , dinoFound){

        if(err){ res.redirect("/dinos")}

        else {res.render("dinos/show", {dinos: dinoFound});

        };
    })
});

//!===================================================================================
//! 5-                   EDIT ROUTE - SHOW EDIT FORM FOR BLOG
//!===========================================================================================

router.get("/dinos/:id/edit",isLoggedIn,  function(req ,res){

    Dino.findById(req.params.id , function(err , foundDino){

        if(err){res.redirect("/dinos")
                console.log(err)}

        else{res.render("dinos/edit" , {dinos: foundDino});}
    })


});

//!===================================================================================================
//!                     6-     UPDATE ROUTE - UPDATE A PARTICULAR FORM THEN REDIRECT
//!=================================================================================================

router.put("/dinos/:id" ,isLoggedIn, function(req , res){



    Dino.findByIdAndUpdate(req.params.id , req.body.dinos , function(err , updatedDino){

        if(err){
            res.redirect("/dinos")
        }
        else{ res.redirect("/dinos/"+ req.params.id)}
    })
});

//!======================================================================================================
//!                     7-       DELETE ROUTE - DELETE A PARTICULAR FORM THEN REDIRECT
//!======================================================================================================

router.delete("/dinos/:id" , function(req , res){

    Dino.findByIdAndDelete(req.params.id , function(err){

        if(err){res.redirect("/dinos");}
        else{ res.redirect("/dinos")};
    })
});


function checkBlogOwnership(req , res , next){
        if(req.isAuthenticated()){
            Dino.findById(req.params.id  , function(err , dinoFound){
                if(err){
              res.redirect("back")}
              else { if(dinoFound.author.id.equals(req.user._id))
                {
              next();
              }
            else{ res.redirect("back")}
            }

            });
         }else{
             res.redirect("/login");
             res.send("YOU NEED TO BE LOGGED IN TO DO THAT!")
         }
        }

        function isLoggedIn(req , res, next){
            if(req.isAuthenticated()){
                return next();
            };
             res.redirect("/login")}


module.exports = router

var express = require("express"),
    router = express.Router(),
    passport = require("passport"),
    User = require("../models/user");

    
    //!==============================================================================================
//!                                       AUTH ROUTE
//!===============================================================================================
//! ========================> || SHOW SIGN UP FORM || <============================================
router.get("/register" , function(req,res){
    res.render("auth/register");
   
});

//! ========================> || HANDLES SIGN UP LOGIC || <===========================================
router.post("/register", function(req , res){
    
    var newUser = new User({username: req.body.username});
    
    User.register(newUser , req.body.password , function(err , user){
        if(err){console.log(err);
        return res.redirect('/register')};
        user.authenticate("local");
        res.redirect("/dinos");

    })
});


//!========================> || SHOW LOGIN FORM || <===================================================

router.get("/login" , function(req , res){
    res.render("auth/login");
});

//!========================> || HANDLES LOGIN LOGIC || <===============================================
//*              app.post("/login" , middleware , function(req , res){})
router.post("/login", passport.authenticate("local", {
    failureRedirect : "/login",
    successRedirect : "/dinos"
})
 ,function(req , res){

});
//!=======================> || LOGOUT ROUTE || <=======================================================
router.get("/logout" , function(req , res){
    req.logout();
    res.redirect("/");
});


function isLoggedIn(req , res, next){
    if(req.isAuthenticated()){
        return next();
    };
     res.redirect("/login")}

    module.exports = router
var app =      require("express")(),
passport =     require("passport"),
methodOverride = require("method-override"),
mongoose =     require("mongoose"),
bodyParser =   require('body-parser'),
localStrategy      =  require("passport-local"),
passportLocalMongoose =  require("passport-local-mongoose"),
authRoutes          =         require("./routes/auth"),
dinoRoutes          =         require("./routes/dino"),
User           =         require("./models/user");

app.use(methodOverride("_method"));
app.set("view engine" , "ejs");
app.use(bodyParser(encodeURI({extended: true})));
mongoose.connect("mongodb://localhost/DinosaurApp");

 //!=====================> || Passport Config || <================================
 app.use( require("express-session")({
    secret:" Dinosaurs are extinct",
    resave: false,
    saveUnitialized: false
}));

    app.use(passport.initialize());
    app.use(passport.session());
    passport.use(new localStrategy(User.authenticate()));
    passport.serializeUser(User.serializeUser());
    passport.deserializeUser(User.deserializeUser());

    app.use(function(req , res , next){
        res.locals.currentUser = req.user;
        next();
    });
    app.use(dinoRoutes);
    app.use(authRoutes);

    app.listen(3000,function(){console.log("Server has started")})
